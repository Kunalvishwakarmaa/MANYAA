import './App.css';

import AllRoutes from './routes/AllRoutes';

function App() {
  return (
    <div >
      <AllRoutes />
    </div>
  );
}

export default App;
