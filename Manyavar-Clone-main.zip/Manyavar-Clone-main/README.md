# Manyavar-Clone

Manyavar is a popular ethnic wear brand in India, known for its exquisite collection of traditional men's clothing such as sherwanis, kurtas, and suits. The brand has a website, www.manyavar.com, where customers can browse and purchase their products online.


<p><img src="https://manyavar-clone-nine.vercel.app/static/media/manyavarFullLogo.3395bcf9230e803521d3.webp" width='400' /> </p>


<h2>Tech Stacks</h2>
<p><img src="https://cdn.iconscout.com/icon/free/png-256/html-2752158-2284975.png?w=256&f=avif" width='80' alt="HTML" /> 
<img src="https://cdn.iconscout.com/icon/free/png-256/css-alt-3521367-2944811.png?w=256&f=avif" width='80' alt="CSS" />
<img src="https://cdn.iconscout.com/icon/free/png-256/javascript-3628858-3029998.png?w=256&f=avif" width='80' alt="JavaScript"/>
 <img src="https://www.dbi-services.com/wp-content/uploads/2022/01/Logo-Mongodb-carre.png" width='80' alt="Mongo DB" />
 <img src="https://adware-technologies.s3.amazonaws.com/uploads/technology/thumbnail/20/express-js.png" width='80' alt="Express js" />
<img src="https://cdn.iconscout.com/icon/free/png-256/react-3-1175109.png?w=256&f=avif" width='80' alt="REACT" />
 <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d9/Node.js_logo.svg/2560px-Node.js_logo.svg.png" width='80' alt="Node js" />
<img src="https://cdn.zapier.com/storage/blog/4ec8fc7dc3a75758a3913bab9e5a4fd8_2.500x278.png" width='80' alt="Redux" />
<img src="https://www.happylifecreators.com/wp/wp-content/uploads/2022/06/chakra-ui_title2-400x400.png" width='80' alt="Chakra UI" />
<img src="https://mui.com/static/logo.png" width='80' alt="MUI" />  
 
 </p>
<h2>functionality</h2>
<p>
<img src="https://img.freepik.com/premium-vector/authentication-icon-simple-element-illustration-authentication-concept-symbol-design-can-be-used-web-mobile_159242-6853.jpg?w=2000" width='100' height='100px' alt="Cyclic"/>
<img src="https://t3.ftcdn.net/jpg/03/91/34/12/360_F_391341245_KZoIHUJSA4NpdQhjlfPxEtKTQVF4eDfp.jpg" width='100' height='100px' alt="Vercel"/>
</p>


</p>
<h2>Deployment</h2>
<p>
<img src="https://www.cyclic.sh/og/summary_large_image.png" width='100' height='50px' alt="Cyclic"/>
<img src="https://miro.medium.com/max/1400/1*Rv6kW7EnWmShq7DKEb9-_A@2x.jpeg" width='150' height='50px' alt="Vercel"/>
</p>


